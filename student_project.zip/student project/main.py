from student import avg, max_grade, min_grade, check_status

name = input("Enter student name: ")
grades_input = input("Enter student grades separated by spaces: ")
grades = [float(x) for x in grades_input.split()]

print("\nStudent name:", name)
print("Average grade:", avg(grades))
print("Maximum grade:", max_grade(grades))
print("Minimum grade:", min_grade(grades))
print("Status:", check_status(grades))
