menu = {
    "coffee": 80000,
    "tea": 50000,
    "cake": 120000,
    "latte": 100000,
    "juice": 90000
}


def show_menu():
    print("\n===== Cafe Menu =====")

    for product, price in menu.items():
        print(product, ":", price, "Toman")
