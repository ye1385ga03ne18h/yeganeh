from Order import orders


def calculate_total():
    total = 0

    for order in orders:
        total += order["price"] * order["quantity"]

    return total


def calculate_discount(total):
    if total > 1000000:
        discount = total * 0.10
    else:
        discount = 0

    return discount


def print_invoice():
    if len(orders) == 0:
        print("No orders to print!")
        return

    print("\n========== Invoice ==========")

    for order in orders:
        print(
            order["product"],
            "| Quantity:", order["quantity"],
            "| Price:", order["price"],
            "| Subtotal:", order["price"] * order["quantity"]
        )

    total = calculate_total()
    discount = calculate_discount(total)
    final_price = total - discount

    print("----------------------------")
    print("Total:", total, "Toman")
    print("Discount:", discount, "Toman")
    print("Final price:", final_price, "Toman")
    print("============================")
