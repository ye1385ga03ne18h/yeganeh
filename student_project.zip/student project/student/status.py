from .grades import avg


def check_status(grades):
    if avg(grades) > 10:
        return "Passed"
    else:
        return "Failed"
